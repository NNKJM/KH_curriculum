package meal_kit;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class P06_Order extends JFrame {

	Connection con = null;

	// db에 sql문을 전송하는 객체
	PreparedStatement pstmt = null;

	// sql문의 실행 결과를 저장할 객체
	ResultSet rs = null;

	// sql문 저장할 변수
	String sql = null;

	DefaultTableModel model;
	static String menu_name;

	void connect() {

		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "web";
		String password = "1234";

		try {
			// 1. 접속할 오라클 데베 드라이버를 메모리에 올리기 - 동적 작업
			Class.forName(driver);

			// 2. 오라클 데베와 연결 시도
			con = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public P06_Order() {
		// 윗쪽 버튼
		setTitle("주문 페이지");

		JTabbedPane tab = new JTabbedPane();

		JPanel con1 = new JPanel(); // 한식
		JPanel con2 = new JPanel(); // 중식
		JPanel con3 = new JPanel(); // 일식
		JPanel con4 = new JPanel(); // 양식
		JPanel con5 = new JPanel(); // 기타

		con1.setLayout(null); con1.setPreferredSize(new Dimension(500, 900));
		con2.setLayout(null); con2.setPreferredSize(new Dimension(500, 900));
		con3.setLayout(null); con3.setPreferredSize(new Dimension(500, 900));
		con4.setLayout(null); con4.setPreferredSize(new Dimension(500, 900));
		con5.setLayout(null); con5.setPreferredSize(new Dimension(500, 900));
		JScrollPane jsp1 = new JScrollPane(con1, ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		JScrollPane jsp2 = new JScrollPane(con2, ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		JScrollPane jsp3 = new JScrollPane(con3, ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		JScrollPane jsp4 = new JScrollPane(con4, ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		JScrollPane jsp5 = new JScrollPane(con5, ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);

		tab.add(jsp1, "한식");
		tab.add(jsp2, "중식");
		tab.add(jsp3, "일식");
		tab.add(jsp4, "양식");
		tab.add(jsp5, "기타");

		// 메뉴
		// 음식이름, 이후에는 메뉴 DB 받아서 출력할 것, rs.getString("name"), 고유키
		// 음식사진, 메뉴DB에 음식사진 주소를 받아서 출력 (ex."images/kimchi.jpg")
		// 이후에 priceN[] = new int[menu.length]; // 음식가격
		// 음식평점 (Null값 가능)

		connect();

		String[] header = { "name", "price", "rating", "image directory" };
		model = new DefaultTableModel(header, 0);

		String[] menu;
		int[] price;
		double[] rating;
		String[] imagedir;
		ImageIcon[] image;

		// 1. 한식
		model = getModel("한식");
		menu = new String[model.getRowCount()];
		price = new int[model.getRowCount()];
		rating = new double[model.getRowCount()];
		imagedir = new String[model.getRowCount()];

		JButton btKr[] = new JButton[model.getRowCount()]; // 버튼 생성용
		JLabel jlKr1[] = new JLabel[model.getRowCount()]; // 라벨 생성용
		JLabel jlKr2[] = new JLabel[model.getRowCount()];

		for (int i = 0; i < model.getRowCount(); i++) {
			menu[i] = model.getValueAt(i, 0).toString();
			price[i] = (int) model.getValueAt(i, 1);
			rating[i] = (double) model.getValueAt(i, 2);
			imagedir[i] = model.getValueAt(i, 3).toString();
			// image[i] = new ImageIcon(imagedir[i]);
			btKr[i] = new JButton(imagedir[i]);
			if (i % 2 == 0) {
				btKr[i].setBounds(25 + 90 * i, 25, 120, 120);
			} else {
				btKr[i].setBounds(25 + 90 * (i - 1), 205, 120, 120);
			}
			String menu_name = menu[i];
			btKr[i].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					new Page7(menu_name);
				}
			});
			jlKr1[i] = new JLabel(menu[i] + " : " + price[i] + "원", JLabel.CENTER);
			jlKr1[i].setBounds(btKr[i].getX(), btKr[i].getY() + 130, 120, 20);
			jlKr2[i] = new JLabel("평점 : " + rating[i] + " / 5.0", JLabel.CENTER);
			jlKr2[i].setBounds(btKr[i].getX(), btKr[i].getY() + 150, 120, 20);

			con1.add(btKr[i]);
			con1.add(jlKr1[i]);
			con1.add(jlKr2[i]);
		}
		model.setRowCount(0);

		// 2. 중식
		model = getModel("중식");
		menu = new String[model.getRowCount()];
		price = new int[model.getRowCount()];
		rating = new double[model.getRowCount()];
		imagedir = new String[model.getRowCount()];

		JButton btCn[] = new JButton[model.getRowCount()]; // 버튼 생성용
		JLabel jlCn1[] = new JLabel[model.getRowCount()]; // 라벨 생성용
		JLabel jlCn2[] = new JLabel[model.getRowCount()];

		for (int i = 0; i < model.getRowCount(); i++) {
			menu[i] = model.getValueAt(i, 0).toString();
			price[i] = (int) model.getValueAt(i, 1);
			rating[i] = (double) model.getValueAt(i, 2);
			imagedir[i] = model.getValueAt(i, 3).toString();
			btCn[i] = new JButton(imagedir[i]);
			if (i % 2 == 0) {
				btCn[i].setBounds(25 + 90 * i, 25, 120, 120);
			} else {
				btCn[i].setBounds(25 + 90 * (i - 1), 205, 120, 120);
			}
			String menu_name = menu[i];
			btCn[i].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					new Page7(menu_name);
					dispose();
				}
			});
			jlCn1[i] = new JLabel(menu[i] + " : " + price[i] + "원", JLabel.CENTER);
			jlCn1[i].setBounds(btCn[i].getX(), btCn[i].getY() + 130, 120, 20);
			jlCn2[i] = new JLabel("평점 : " + rating[i] + " / 5.0", JLabel.CENTER);
			jlCn2[i].setBounds(btCn[i].getX(), btCn[i].getY() + 150, 120, 20);

			con2.add(btCn[i]);
			con2.add(jlCn1[i]);
			con2.add(jlCn2[i]);
		}
		model.setRowCount(0);

		// 3. 일식
		model = getModel("일식");
		menu = new String[model.getRowCount()];
		price = new int[model.getRowCount()];
		rating = new double[model.getRowCount()];
		imagedir = new String[model.getRowCount()];

		JButton btJp[] = new JButton[model.getRowCount()]; // 버튼 생성용
		JLabel jlJp1[] = new JLabel[model.getRowCount()]; // 라벨 생성용
		JLabel jlJp2[] = new JLabel[model.getRowCount()];

		for (int i = 0; i < model.getRowCount(); i++) {
			menu[i] = model.getValueAt(i, 0).toString();
			price[i] = (int) model.getValueAt(i, 1);
			rating[i] = (double) model.getValueAt(i, 2);
			imagedir[i] = model.getValueAt(i, 3).toString();
			btJp[i] = new JButton(imagedir[i]);
			if (i % 2 == 0) {
				btJp[i].setBounds(25 + 90 * i, 25, 120, 120);
			} else {
				btJp[i].setBounds(25 + 90 * (i - 1), 205, 120, 120);
			}
			String menu_name = menu[i];
			btJp[i].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					new Page7(menu_name);
				}
			});
			jlJp1[i] = new JLabel(menu[i] + " : " + price[i] + "원", JLabel.CENTER);
			jlJp1[i].setBounds(btJp[i].getX(), btJp[i].getY() + 130, 120, 20);
			jlJp2[i] = new JLabel("평점 : " + rating[i] + " / 5.0", JLabel.CENTER);
			jlJp2[i].setBounds(btJp[i].getX(), btJp[i].getY() + 150, 120, 20);

			con3.add(btJp[i]);
			con3.add(jlJp1[i]);
			con3.add(jlJp2[i]);
		}
		model.setRowCount(0);

		// 4. 양식
		DefaultTableModel modelEn = getModel("양식");
		String[] menuEn = new String[modelEn.getRowCount()];
		int[] priceEn = new int[modelEn.getRowCount()];
		double[] ratingEn = new double[modelEn.getRowCount()];
		String[] imageEn = new String[modelEn.getRowCount()];

		JButton btEn[] = new JButton[modelEn.getRowCount()]; // 버튼 생성용
		JLabel jlEn1[] = new JLabel[modelEn.getRowCount()]; // 라벨 생성용
		JLabel jlEn2[] = new JLabel[modelEn.getRowCount()];

		for (int i = 0; i < modelEn.getRowCount(); i++) {
			menuEn[i] = modelEn.getValueAt(i, 0).toString();
			priceEn[i] = (int) modelEn.getValueAt(i, 1);
			ratingEn[i] = (double) modelEn.getValueAt(i, 2);
			imageEn[i] = modelEn.getValueAt(i, 3).toString();
			btEn[i] = new JButton(imageEn[i]);
			if (i % 2 == 0) {
				btEn[i].setBounds(25 + 90 * i, 25, 120, 120);
			} else {
				btEn[i].setBounds(25 + 90 * (i - 1), 205, 120, 120);
			}
			String menu_name = menuEn[i];
			btEn[i].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					new Page7(menu_name);
				}
			});
			jlEn1[i] = new JLabel(menuEn[i] + " : " + priceEn[i] + "원", JLabel.CENTER);
			jlEn1[i].setBounds(btEn[i].getX(), btEn[i].getY() + 130, 120, 20);
			jlEn2[i] = new JLabel("평점 : " + ratingEn[i] + " / 5.0", JLabel.CENTER);
			jlEn2[i].setBounds(btEn[i].getX(), btEn[i].getY() + 150, 120, 20);

			con4.add(btEn[i]);
			con4.add(jlEn1[i]);
			con4.add(jlEn2[i]);
		}
		model.setRowCount(0);

		JButton exit = new JButton("나가기");
		JPanel cons = new JPanel(new BorderLayout(0, 50));
		add(tab, BorderLayout.CENTER);
		add(cons, BorderLayout.SOUTH);

		// setResizable(false);
		setBounds(300, 300, 900, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}

	DefaultTableModel getModel(String sort) {
		try {
			sql = "select * from menu where sort = ?";
			// sql = "select menu.*, orders.avg(rating) from menu where sort = ? join orders on menu.no = order.no";
			pstmt = con.prepareStatement(sql);

			pstmt.setString(1, sort);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				String name = rs.getString("menu_name");
				int price = rs.getInt("price");
				double rating = rs.getDouble("rating");
				String dir = rs.getString("dir");
				Object[] data = {name, price, rating, dir};
				model.addRow(data);
			}
			rs.close(); pstmt.close(); 
		} catch (Exception e) {
			e.printStackTrace();
		}
		return model;
	}
}
