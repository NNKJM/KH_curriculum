package meal_kit;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ShoppingCart extends JFrame {

   private JPanel contentPane;
   private JTextField addrText;
   int count;
   int sum = 0;
   int sumPrice;
   int totalPrice;
   List<String> mealKit;
   List<Integer> mealKit_price,mealKit_price2;
   List<String> mealKit_amount;
  
   Connection con = null;            // DB와 연결하는 객체
   PreparedStatement pstmt = null;      // SQL문을 DB에 전송하는 객체
   ResultSet rs = null;            // SQL문 실행 결과를 가지고 있는 객체
   String sql = null;               // SQL문을 저장하는 문자열 변수.
  
   public ShoppingCart() {
     
        JFrame frame = new JFrame("밀키트 주문 시스템__장바구니");
//      setTitle("밀키트 주문 시스템__장바구니");
     
      contentPane = new JPanel();
      contentPane.setBackground(new Color(210, 229, 255));
      contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
      setContentPane(contentPane);
      contentPane.setLayout(null);
      //contentPane.setFont(new Font("맑은 고딕", Font.BOLD, 20));
     
      JLabel cart = new JLabel("장바구니");
      cart.setFont(new Font("맑은 고딕", Font.BOLD, 25));
      cart.setForeground(new Color(0, 0, 51));
      cart.setBounds(230, 30, 400, 40);
      contentPane.add(cart);
     
      JLabel address = new JLabel("주소");
      address.setFont(new Font("맑은 고딕", Font.BOLD, 20));
      address.setBounds(30, 95, 60, 20);
      contentPane.add(address);
     
      addrText = new JTextField();
      addrText.setFont(new Font("맑은 고딕", Font.BOLD, 18));
      addrText.setBounds(95, 90, 450, 35);
      contentPane.add(addrText);
      addrText.setColumns(50);
     
      JButton addrButton = new JButton("변경");
      addrButton.setFont(new Font("맑은 고딕", Font.BOLD, 18));
      addrButton.setBounds(570, 90, 100, 35);
      contentPane.add(addrButton);
     
      //JLabel menuLabel = new JLabel("메뉴                               가격               수량");
      JLabel menuLabel = new JLabel("메뉴");
      menuLabel.setFont(new Font("맑은 고딕", Font.BOLD, 18));
      menuLabel.setBounds(30, 150, 65, 20);
      contentPane.add(menuLabel);
     
      JLabel priceLabel = new JLabel("단가");
      priceLabel.setFont(new Font("맑은 고딕", Font.BOLD, 18));
      priceLabel.setBounds(290, 150, 65, 20);
      contentPane.add(priceLabel);
           
      JLabel amoutLabel = new JLabel("수량");
      amoutLabel.setFont(new Font("맑은 고딕", Font.BOLD, 18));
      amoutLabel.setBounds(460, 150, 65, 20);
      contentPane.add(amoutLabel);
     
      JLabel priceLabel2 = new JLabel("총 금액");
      priceLabel2.setFont(new Font("맑은 고딕", Font.BOLD, 18));
      priceLabel2.setBounds(590, 150, 65, 20);
      contentPane.add(priceLabel2);     
     
      mealKit = new ArrayList<String>();
      mealKit_price = new ArrayList<Integer>();
      mealKit_price2 = new ArrayList<Integer>();
      mealKit_amount = new ArrayList<String>();
     
      connect();
      getMenu();
     
      // String mealKit[] = {"오뚜기 김치찌개", "눈꽃 함박 스테이크", "된장찌개", "양념치킨", "찌개용 돼지고기 추가(100g)"};
      //int mealKit_price[] = {12300, 16900, 2300, 2300, 16900};
      JTextField menu[] = new JTextField[mealKit.size()];
      JLabel price[] = new JLabel[mealKit.size()];
      JLabel price2[] = new JLabel[mealKit.size()];
       JTextField amount[] = new JTextField[mealKit.size()];
       JButton minus[] = new JButton[mealKit.size()];
       JButton plus[] = new JButton[mealKit.size()];
      
      
      for (int i = 0; i < mealKit.size(); i++) {
         menu[i] = new JTextField(mealKit.get(i));
         menu[i].setFont(new Font("맑은 고딕", Font.BOLD, 18));
         menu[i].setBounds(30, 180 + i*40, 250, 30);
         contentPane.add(menu[i]);
         menu[i].setColumns(10);
        
         //price[i] = new JLabel(mealKit_price[i] + "원");
         price[i] = new JLabel(mealKit_price.get(i) + "원");
         price[i].setFont(new Font("맑은 고딕", Font.BOLD, 20));
         price[i].setBounds(290, 180 + i*40, 100, 20);
         contentPane.add(price[i]);
        
         minus[i] = new JButton("-");
         minus[i].setBounds(400, 180 + i*40, 45, 30);
         contentPane.add(minus[i]);
        
         amount[i] = new JTextField(mealKit_amount.get(i));
         amount[i].setBounds(445, 180 + i*40, 66, 30);
         amount[i].setFont(new Font("맑은 고딕", Font.BOLD, 20));
         amount[i].setHorizontalAlignment(SwingConstants.CENTER);
         amount[i].setEditable(false);
         amount[i].setColumns(2);
         contentPane.add(amount[i]);
                 
         plus[i] = new JButton("+");
         plus[i].setBounds(510, 180 + i*40, 45, 30);
         contentPane.add(plus[i]);  
        
         price2[i] = new JLabel(mealKit_price2.get(i) + "원");
         price2[i].setFont(new Font("맑은 고딕", Font.BOLD, 20));
         price2[i].setBounds(590, 180 + i*40, 100, 20);
         contentPane.add(price2[i]);
        
         sum += mealKit_price2.get(i);
      }
     
      JLabel sumLabel = new JLabel("금액 합계 : " + sum + "원");
      sumLabel.setFont(new Font("맑은 고딕", Font.BOLD, 20));
      sumLabel.setBounds(190, 550, 200, 50);
      contentPane.add(sumLabel);

      JButton orderButton = new JButton("주문하기");
      orderButton.setFont(new Font("맑은 고딕", Font.BOLD, 18));
      orderButton.setBounds(220, 600, 150, 35);
      //orderButton.setBounds(220, 340, 150, 35);
      contentPane.add(orderButton);  
     
      //setFont(new Font("맑은 고딕", Font.BOLD, 20));
      frame.add(contentPane);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setBounds(100, 100, 800, 800);
      frame.setVisible(true);
     
     
          for (int i = 0; i < menu.length; i++) {
               int j = i;
               count = 0;
               sumPrice = 0;
               totalPrice = 0;

               plus[i].addActionListener(new ActionListener() {
                 
                   @Override
                   public void actionPerformed(ActionEvent e) {
                       count = Integer.parseInt(amount[j].getText()) + 1;
                       amount[j].setText(count + "");
                      
                        sumPrice = mealKit_price.get(j)*count;
                        price2[j].setText(sumPrice + "원");
                                               
                        totalPrice = sum + sumPrice - mealKit_price.get(j);
                        sumLabel.setText("금액 합계 : " + totalPrice + "원");
                                             
                       if (count > 0) {
                          minus[j].setEnabled(true);
                       }
                   }
               });
              
               minus[i].addActionListener(new ActionListener() {

                   @Override
                   public void actionPerformed(ActionEvent e) {
                      count = Integer.parseInt(amount[j].getText());
                           
                       if (count > 0) {
                           count = Integer.parseInt(amount[j].getText()) - 1;
                           amount[j].setText(count + "");
                          
                           sumPrice = mealKit_price.get(j)*count;
                           price2[j].setText(sumPrice + "원");
                                                  
                           totalPrice = sum - sumPrice + mealKit_price.get(j);
                           sumLabel.setText("금액 합계 : " + totalPrice + "원");
                                                
                          
                           minus[j].setEnabled(true);

                       } else {
                          minus[j].setEnabled(false);
                       }
                   }
               });

         }   // for문 end
         
          orderButton.addActionListener(new ActionListener() {
        
         @Override
         public void actionPerformed(ActionEvent e) {
           
           
         }
      });

   } // 생성자 end
  
   // DB를 연동하는 메서드
   void connect() {
      String driver = "oracle.jdbc.driver.OracleDriver";
      String url = "jdbc:oracle:thin:@localhost:1521:xe";
      String user = "web";
      String password = "1234";
     
      try {
         // 1. 접속할 오라클 데이터베이스 드라이버를 메모리자 올리자.
         // -동적작업 (프로그램 실행시 메모리에 업로드 됨.)
         Class.forName(driver);
        
         // 2. 오라클 데이터베이스와 연결을 시도.
         con = DriverManager.getConnection(url, user, password);
        
      } catch (Exception e) {

         e.printStackTrace();
      }
     
           
   }   // connect() 메서드 end  
  
   void getMenu() {

      try {
         // 1. 오라클 데이터베이스에 전송할 SQL문 작성
         sql = "select menu, price, amount "
               + "from shoppingCart where orderStatus = 'N'";
        
         pstmt = con.prepareStatement(sql);
        
         // 2. 오라클 데이터베이스에 SQL문 전송 및 SQL문 실행
         rs = pstmt.executeQuery();
        
         while(rs.next()) {
            String menu = rs.getString("menu");
            int price = rs.getInt("price");
            String amount = rs.getString("amount");
           
            int price2 = price * Integer.parseInt(amount);
           
            mealKit.add(menu);
            mealKit_price.add(price);
            mealKit_price2.add(price2);
            mealKit_amount.add(amount);
         }
        
         // 3. 오라클 데이터베이스에 연결되어 있던 자원 종료.
         rs.close(); pstmt.close(); // con.close();
        
      } catch (SQLException e) {
         e.printStackTrace();
      }
     
   } // getMenu() 메서드 end
  
      public static void main(String[] args) {
     
      new ShoppingCart();
     
   }
}