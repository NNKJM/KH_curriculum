package meal_kit;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.sql.*;
import java.awt.event.ActionEvent;

public class Password extends JFrame {

   Connection con = null; // DB와 연결하는 객체
   PreparedStatement pstmt = null; // SQL문을 DB에 전송하는 객체
   ResultSet rs = null; // SQL문 실행 결과를 가지고 오는 객체
   String sql = null; // SQL문을 저장하는 문자열 변수
  
   private JPanel contentPane;
   private JTextField jtf1;
   private JTextField jtf2;
   private JTextField jtf3;

   /**
    * Launch the application.
    */
   public static void main(String[] args) {
      EventQueue.invokeLater(new Runnable() {
         public void run() {
            try {
               Password frame = new Password();
               frame.setVisible(true);
            } catch (Exception e) {
               e.printStackTrace();
            }
         }
      });
   }

   /**
    * Create the frame.
    */
   public Password() {
      connect();
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setBounds(100, 100, 450, 300);
      contentPane = new JPanel();
      contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
      setContentPane(contentPane);
      contentPane.setLayout(null);
     
      JLabel jl1 = new JLabel("비밀번호 찾기");
      jl1.setFont(new Font("굴림", Font.PLAIN, 20));
      jl1.setBounds(154, 27, 127, 24);
      contentPane.add(jl1);
     
      JLabel jl2 = new JLabel("아이디");
      jl2.setBounds(114, 79, 50, 18);
      contentPane.add(jl2);
     
      jtf1 = new JTextField();
      jtf1.setBounds(178, 76, 150, 24);
      contentPane.add(jtf1);
      jtf1.setColumns(10);
     
      JLabel jl3 = new JLabel("이름");
      jl3.setBounds(114, 109, 50, 18);
      contentPane.add(jl3);
     
      jtf2 = new JTextField();
      jtf2.setBounds(178, 106, 150, 24);
      contentPane.add(jtf2);
      jtf2.setColumns(10);
     
      JLabel jl4 = new JLabel("연락처");
      jl4.setBounds(114, 139, 50, 18);
      contentPane.add(jl4);
     
      jtf3 = new JTextField();
      jtf3.setBounds(178, 136, 150, 24);
      contentPane.add(jtf3);
      jtf3.setColumns(10);
     
      JButton jb1 = new JButton("비밀번호 찾기");
      jb1.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent arg0) {
        
            findPsw();
           
         }
      });
      jb1.setBounds(160, 184, 121, 27);
      contentPane.add(jb1);
   }
  
  
    void connect() {
         
          String driver = "oracle.jdbc.driver.OracleDriver";
          String url = "jdbc:oracle:thin:@localhost:1521:xe";
          String user = "web";
          String password = "1234";
         
          try {
             //1. 접속할 오라클 데베 드라이버를 메모리에 올리기 - 동적 작업
             Class.forName(driver);
            
             //2. 오라클 데베와 연결 시도
             con = DriverManager.getConnection(url, user, password);
          } catch (Exception e) {
             e.printStackTrace();
          }
         
       }//connect()메소드 end
  
   void findPsw() {

      try {
         sql = "select id, name, phone_number, password from member where id = ?";
         pstmt = con.prepareStatement(sql);
         pstmt.setString(1, jtf1.getText());
         rs = pstmt.executeQuery();
        
         while(rs.next()) {
            String id = rs.getString("id");
            String name = rs.getString("name");
            String phone_number = rs.getString("phone");
            String password = rs.getString("password");

            if(jtf1.getText().equals(id)) {
               if(jtf2.getText().equals(name)) {
                  if(jtf3.getText().equals(phone_number)) {
                     JOptionPane.showMessageDialog(null, name + " 회원님의 비밀번호는 " + password + " 입니다." );
                     dispose();
                        new Login();
                  }else {
                     JOptionPane.showMessageDialog(null, "입력하신 정보와 일치하는 계정이 존재하지 않습니다.");
                  }
               }else {
                  JOptionPane.showMessageDialog(null, "입력하신 정보와 일치하는 계정이 존재하지 않습니다.");
               }
            }else {
               JOptionPane.showMessageDialog(null, "입력하신 정보와 일치하는 계정이 존재하지 않습니다.");
            }
         }
        
         // rs.close(); pstmt.close(); con.close();
        
      } catch (SQLException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
     
   }

}