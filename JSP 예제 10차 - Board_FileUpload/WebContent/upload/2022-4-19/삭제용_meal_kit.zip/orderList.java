package meal_kit;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class orderList extends JFrame{
  
   private JPanel contentPane;
  
   public orderList() {
     
      setTitle("밀키트 주문 시스템__주문내역");
     
      contentPane = new JPanel();
      contentPane.setBackground(new Color(210, 229, 255));
      contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
      setContentPane(contentPane);
      contentPane.setLayout(null);
      //contentPane.setFont(new Font("맑은 고딕", Font.BOLD, 20));
     
      JLabel cart = new JLabel("주문내역");
      cart.setFont(new Font("맑은 고딕", Font.BOLD, 25));
      cart.setForeground(new Color(0, 0, 51));
      cart.setBounds(230, 30, 100, 40);
      contentPane.add(cart);

      JLabel orderDate = new JLabel("2022-03-04");
      orderDate.setFont(new Font("맑은 고딕", Font.BOLD, 18));
      orderDate.setBounds(30, 100, 150, 20);
      contentPane.add(orderDate);
     
      String mealKit[] = {"오뚜기 김치찌개", "눈꽃 함박 스테이크", "찌개용 돼지고기 추가(100g)"};
      int mealKit_price[] = {12300, 16900, 2300};
      JTextField menu[] = new JTextField[mealKit.length];
      JLabel rank[] = new JLabel[mealKit.length];
       JTextField amount[] = new JTextField[mealKit.length];
       JButton minus[] = new JButton[mealKit.length];
       JButton plus[] = new JButton[mealKit.length];
      
      
      for (int i = 0; i < mealKit.length; i++) {
         menu[i] = new JTextField(mealKit[i]);
         menu[i].setFont(new Font("맑은 고딕", Font.BOLD, 18));
         menu[i].setBounds(30, 140 + i*40, 250, 30);
         contentPane.add(menu[i]);
         menu[i].setColumns(10);
        
         amount[i] = new JTextField();
         amount[i].setBounds(290, 140 + i*40, 66, 30);
         amount[i].setFont(new Font("맑은 고딕", Font.BOLD, 20));
         amount[i].setHorizontalAlignment(SwingConstants.CENTER);
         amount[i].setColumns(2);
         contentPane.add(amount[i]);
        
         rank[i] = new JLabel("/ 5.0");
         rank[i].setFont(new Font("맑은 고딕", Font.BOLD, 20));
         rank[i].setBounds(360, 140 + i*40, 100, 20);
         contentPane.add(rank[i]);
        
         JButton rankButton = new JButton("평점 남기기");
         rankButton.setFont(new Font("맑은 고딕", Font.BOLD, 18));
         rankButton.setBounds(420, 140 + i*40, 130, 30);
         contentPane.add(rankButton);  
        
      }

      //setFont(new Font("맑은 고딕", Font.BOLD, 20));
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setBounds(100, 100, 600, 500);
      setVisible(true);
  
   }
  

   public static void main(String[] args) {
      new orderList();

   }

}

