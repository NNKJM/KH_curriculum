package meal_kit;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;

public class P06_Order_BU extends JFrame{

	public P06_Order_BU() {
		// 윗쪽 버튼
		setTitle("주문 페이지");
		
		JToggleButton jtb1 = new JToggleButton("한식");
		JToggleButton jtb2 = new JToggleButton("중식");
		JToggleButton jtb3 = new JToggleButton("일식");
		JToggleButton jtb4 = new JToggleButton("양식");
		JToggleButton jtb5 = new JToggleButton("기타");
		jtb1.setPreferredSize(new Dimension(90, 30));
		jtb2.setPreferredSize(new Dimension(90, 30));
		jtb3.setPreferredSize(new Dimension(90, 30));
		jtb4.setPreferredSize(new Dimension(90, 30));
		jtb5.setPreferredSize(new Dimension(90, 30));
		JPanel group = new JPanel();
		

		ButtonGroup bg = new ButtonGroup();
		bg.add(jtb1); group.add(jtb1);
		bg.add(jtb2); group.add(jtb2);
		bg.add(jtb3); group.add(jtb3);
		bg.add(jtb4); group.add(jtb4);
		bg.add(jtb5); group.add(jtb5);
		jtb1.setForeground(Color.WHITE); jtb1.setBackground(new Color(52, 152, 219));
		jtb2.setForeground(Color.WHITE); jtb2.setBackground(new Color(52, 152, 219));
		jtb3.setForeground(Color.WHITE); jtb3.setBackground(new Color(52, 152, 219));
		jtb4.setForeground(Color.WHITE); jtb4.setBackground(new Color(52, 152, 219));
		jtb5.setForeground(Color.WHITE); jtb5.setBackground(new Color(52, 152, 219));

		group.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 15));
		
		/*
		 * DB 연결
		 * String driver = "oracle.jdbc.driver.OracleDriver";
		 * String url = "jdbc:oracle:thin:@localhost:1521:xe";
		 * String user = "web";
		 * String password = "1234";
		 */
		
		/*
		 * 바로 SQL 실행
		 * sql = "select * from menu";
		 * pstmt = con.prepareStatement(sql);
		 * rs = pstmt.executeQuery();
		 */
		
		String menu[] = {"김치찌개", "된장찌개", "미역국", "스테이크"}; // 음식이름, 이후에는 메뉴 DB 받아서 출력할 것, rs.getString("name")
		ImageIcon image[] = new ImageIcon[menu.length]; // 음식사진, 메뉴DB에 음식사진 주소를 받아서 출력 // 현재는 없으니 버튼으로 대체
		// int price[] = new int[menu.length]; // 음식가격
		int price[] = {1000, 2000, 3000, 4000};
		float rank[] = new float[menu.length]; // 음식평점
		// 메뉴DB 구성은 음식이름(고유키), 음식사진("images/kimchi.jpg") 형태의 주소, 음식가격, 음식평점(Null값 가능)
		JPanel main = new JPanel();
		JPanel main1 = new JPanel();
		JPanel main2 = new JPanel();

		JPanel pn[] = new JPanel[menu.length];
		JButton bt[] = new JButton[menu.length];
		JLabel l[] = new JLabel[menu.length];
		for (int i = 0; i < menu.length; i++) {
            // icon[i] = new ImageIcon(i + ".png");
            // bt[i].setIcon(icon[i]);
			// l[i] = new JLabel(name[i] + " : " + price[i] + "원");
            bt[i] = new JButton(menu[i]);
            bt[i].setSize(100, 100);
            // l[i] = new JLabel(price[i] + "원");
            pn[i] = new JPanel();
            pn[i].setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));
            pn[i].add(bt[i], BorderLayout.NORTH);
            // pn[i].add(l[i], BorderLayout.SOUTH);
            if (i % 2 == 0) {
            	main1.add(pn[i]);
            } else {
            	main2.add(pn[i]);
            }
        }
		main1.setLayout(new GridLayout(1, menu.length/2, 20, 20));
		main1.setBorder(BorderFactory.createEmptyBorder(0, 20, 10, 20)); // 좌측 여백 20, 우측 여백 20
		main2.setLayout(new GridLayout(1, menu.length/2, 20, 20));
		main2.setBorder(BorderFactory.createEmptyBorder(0, 20, 10, 20)); // 좌측 여백 20, 우측 여백 20
		main.setLayout(new GridLayout(2, menu.length/2));
		main.add(main1, BorderLayout.NORTH);
		main.add(main2, BorderLayout.SOUTH);
		JScrollPane jsp = new JScrollPane(main, ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		

		add(group, BorderLayout.NORTH);
		add(jsp, BorderLayout.CENTER);
		setBackground(Color.WHITE);
		
		
		// setResizable(false);
		setBounds(300, 300, 600, 260);
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
		
		jtb1.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
				main.removeAll();

				String menukor[] = {"김치찌개", "된장찌개", "미역국"};
				int pricekor[] = {1000, 2000, 3000};
				for (int i = 0; i < menukor.length; i++) {
		            // icon[i] = new ImageIcon(i + ".png");
		            // bt[i].setIcon(icon[i]);
					// l[i] = new JLabel(name[i] + " : " + price[i] + "원");
		            bt[i] = new JButton(menukor[i]);
		            bt[i].setSize(100, 100);
		            // l[i] = new JLabel(menukor[i] + " : " + pricekor[i] + "원");
		            pn[i] = new JPanel();
		            pn[i].setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));
		            pn[i].add(bt[i], BorderLayout.NORTH);
		            // pn[i].add(l[i], BorderLayout.SOUTH);
		            if (i % 2 == 0) {
		            	main1.add(pn[i]);
		            } else {
		            	main2.add(pn[i]);
		            }
		        }
				main.add(main1);
				main.add(main2);
				main.setLayout(new GridLayout(2, menukor.length/2 + 1, 20, 20));
				main.setBorder(BorderFactory.createEmptyBorder(0, 20, 10, 20));
				// 스크린 한번 비운 후 한식 출력
			}
			@Override
			public void mousePressed(MouseEvent e) {
				main.removeAll();
			}
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
			}
			@Override
			public void mouseClicked(MouseEvent e) {}
		});
	}
	public static void main(String[] args) {
		new P06_Order_BU();
	}
}
